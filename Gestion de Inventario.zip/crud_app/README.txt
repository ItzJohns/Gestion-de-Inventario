CRUD App - PHP + MySQL (básico)
------------------------------
Instrucciones rápidas:
1. Copia la carpeta 'crud_app' dentro de C:\xampp\htdocs\
2. Importa el archivo database.sql en phpMyAdmin para crear la BD y tablas.
3. Abre http://localhost/crud_app/login.php
4. Regístrate y comienza a agregar productos.
